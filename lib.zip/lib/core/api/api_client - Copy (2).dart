import 'package:dio/dio.dart';

/// API client for Handi Roti.
/// IMPORTANT: Production is behind Caddy where /api is routed using handle_path (it strips /api).
/// So we set baseUrl to .../api and all app calls keep using /api/... paths.
/// This results in requests like /api/api/... which Caddy strips to /api/... for the Node server.
class ApiClient {
  ApiClient._();

  static final Dio dio = Dio(
    BaseOptions(
      baseUrl: 'https://order.handiroti.ae/api',
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
    ),
  );
}
