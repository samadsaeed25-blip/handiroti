import 'dart:convert';
import 'package:http/http.dart' as http;

/// Result returned from `/api/vouchers/validate`.
class VoucherValidationResult {
  final bool ok;
  final String? error;
  final String? voucherId;
  final double discountAed;

  const VoucherValidationResult({
    required this.ok,
    this.error,
    this.voucherId,
    required this.discountAed,
  });

  factory VoucherValidationResult.fromJson(Map<String, dynamic> json) {
    final ok = json['ok'] == true;
    final voucher = (json['voucher'] is Map) ? (json['voucher'] as Map).cast<String, dynamic>() : <String, dynamic>{};
    final discRaw = voucher['discount_aed'];
    double disc = 0;
    if (discRaw is num) disc = discRaw.toDouble();
    if (discRaw is String) disc = double.tryParse(discRaw) ?? 0;
    return VoucherValidationResult(
      ok: ok,
      error: json['error']?.toString(),
      voucherId: voucher['voucher_id']?.toString(),
      discountAed: disc,
    );
  }
}


class HandiApi {
  /// Change only if your domain changes
  static const String baseUrl = 'https://order.handiroti.ae';

  final http.Client _client;
  HandiApi({http.Client? client}) : _client = client ?? http.Client();

  Map<String, String> _headers() => const {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  dynamic _decodeJson(String body) {
    try {
      return jsonDecode(body);
    } catch (_) {
      return {'ok': false, 'error': 'Invalid JSON response', 'raw': body};
    }
  }

  Map<String, dynamic> _asError(int code, dynamic body) {
    if (body is Map<String, dynamic>) {
      return {
        'ok': false,
        'status': code,
        'error': body['error'] ?? body['message'] ?? 'Request failed',
        ...body,
      };
    }
    return {
      'ok': false,
      'status': code,
      'error': 'Request failed',
      'body': body,
    };
  }

  /// POST /api/orders
  /// Payload example:
  /// {
  ///  "customer": {"phone":"+9715..","name":".."},
  ///  "address": {"address_line1":"..","area":"..","emirate":"Ras Al Khaimah"},
  ///  "payment_method":"cod",
  ///  "items":[{"item_id":"..","variant_id":"..","quantity":1}]
  /// }
  Future<Map<String, dynamic>> createOrder(Map<String, dynamic> payload) async {
    final uri = Uri.parse('$baseUrl/api/orders');
    final resp = await _client.post(uri, headers: _headers(), body: jsonEncode(payload));
    final body = _decodeJson(resp.body);

    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return (body is Map<String, dynamic>) ? body : {'ok': true, 'data': body};
    }
    return _asError(resp.statusCode, body);
  }

  /// GET /api/orders/:id
  Future<Map<String, dynamic>> getOrder(String orderId) async {
    final uri = Uri.parse('$baseUrl/api/orders/$orderId');
    final resp = await _client.get(uri, headers: _headers());
    final body = _decodeJson(resp.body);

    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return (body is Map<String, dynamic>) ? body : {'ok': true, 'data': body};
    }
    return _asError(resp.statusCode, body);
  }

  /// GET /api/customers/:phone/orders
  Future<Map<String, dynamic>> getCustomerOrders(String phone) async {
    final enc = Uri.encodeComponent(phone);
    final uri = Uri.parse('$baseUrl/api/customers/$enc/orders');
    final resp = await _client.get(uri, headers: _headers());
    final body = _decodeJson(resp.body);

    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return (body is Map<String, dynamic>) ? body : {'ok': true, 'data': body};
    }
    return _asError(resp.statusCode, body);
  }
  Future<VoucherValidationResult> validateVoucher({
    required String voucherCode,
    required double subtotalAed,
    String? customerKey,
  }) async {
    final payload = <String, dynamic>{
      'voucher_code': voucherCode.trim(),
      'subtotal_aed': subtotalAed,
    };
    final ck = customerKey?.trim();
    if (ck != null && ck.isNotEmpty) {
      // Backend treats customer_id as a flexible per-customer key (phone is OK)
      payload['customer_id'] = ck;
    }

    final res = await http.post(
      Uri.parse('$baseUrl/api/vouchers/validate'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(payload),
    );

    try {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return VoucherValidationResult.fromJson(data);
    } catch (_) {
      return const VoucherValidationResult(
        ok: false,
        error: 'Invalid server response',
        voucherId: null,
        discountAed: 0,
      );
    }
  }

}
