import 'package:dio/dio.dart';

import '../../core/api/api_client.dart';
import 'staff_config.dart';

class StaffApi {
  Options _adminOptions() {
    return Options(headers: {
      'x-admin-key': StaffConfig.adminKey,
    });
  }

  Future<List<Map<String, dynamic>>> listOrders({
    String status = 'placed',
    int limit = 50,
  }) async {
    final res = await ApiClient.dio.get(
      '/api/admin/orders',
      queryParameters: {'status': status, 'limit': limit},
      options: _adminOptions(),
    );

    final data = res.data as Map<String, dynamic>;
    if (data['ok'] != true) {
      throw Exception((data['error'] ?? 'Failed to fetch orders').toString());
    }

    final orders = (data['orders'] as List).cast<Map<String, dynamic>>();
    return orders;
  }

  Future<void> updateStatus({
    required String orderId,
    required String status,
    String? note,
  }) async {
    final payload = <String, dynamic>{'status': status};
    if (note != null && note.trim().isNotEmpty) {
      payload['note'] = note.trim();
    }

    final res = await ApiClient.dio.patch(
      '/api/admin/orders/$orderId/status',
      data: payload,
      options: _adminOptions(),
    );

    final data = res.data as Map<String, dynamic>;
    if (data['ok'] != true) {
      throw Exception((data['error'] ?? 'Failed to update status').toString());
    }
  }
}
